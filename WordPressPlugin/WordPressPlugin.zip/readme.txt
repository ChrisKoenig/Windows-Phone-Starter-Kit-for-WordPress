=== Feeds Widget ===
Contributors: Chris Koenig(Microsoft), Kirk Ballou(Touch Titans)
Tags: rss, feed, custom
Requires at least: 2.1
Tested up to: 3.1.8
Stable tag: 1.3
Last Updated: 2014-03-06

Adds feeds required for WP7 App usage

== Description ==

This WordPress plugin will Adds feeds required for WP7 App usage


== Installation ==

1. Download the zip file (link below)
2. Extract wp7.php
3. Upload wp7.php to your wp-content/plugins directory
4. Log in to your WordPress blog
5. Click on "Plugins"�
6. Locate the "WP7 Feeds"� plugin and click "Activate"


== Frequently Asked Questions ==



